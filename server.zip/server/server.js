const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000;

mongoose.Promise = global.Promise;

mongoose
  .connect('mongodb://127.0.0.1:27017/vocabdb', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

require('./api/models/vocabModel');
require('./api/routes/vocabRoutes')(app);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

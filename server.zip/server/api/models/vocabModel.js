// api/models/vocabModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const VocabSchema = new Schema(
  {
    english: {
      type: String,
      required: 'English word is required',
      trim: true,
    },
    german: {
      type: String,
      required: 'German word is required',
      trim: true,
    },
    spanish: {
      type: String,
      required: 'Spanish word is required',
      trim: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    collection: 'vocab', // tên collection
  }
);

module.exports = mongoose.model('Vocab', VocabSchema);

// api/controllers/vocabController.js
const mongoose = require('mongoose');
const Vocab = mongoose.model('Vocab');

// GET /words - list tất cả từ
exports.list_all_words = async (req, res) => {
  try {
    const words = await Vocab.find({}).sort({ createdAt: -1 }).exec();
    res.json(words);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching words', error: err });
  }
};

// POST /words - tạo từ mới
exports.create_a_word = async (req, res) => {
  try {
    const newWord = new Vocab(req.body);
    const saved = await newWord.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: 'Error creating word', error: err });
  }
};

// GET /words/:wordId - lấy 1 từ theo id
exports.read_a_word = async (req, res) => {
  try {
    const word = await Vocab.findById(req.params.wordId).exec();
    if (!word) {
      return res.status(404).json({ message: 'Word not found' });
    }
    res.json(word);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching word', error: err });
  }
};

// PUT /words/:wordId - update 1 từ
exports.update_a_word = async (req, res) => {
  try {
    const updated = await Vocab.findOneAndUpdate(
      { _id: req.params.wordId },
      req.body,
      { new: true }
    ).exec();

    if (!updated) {
      return res.status(404).json({ message: 'Word not found' });
    }

    res.json(updated);
  } catch (err) {
    res.status(400).json({ message: 'Error updating word', error: err });
  }
};

// DELETE /words/:wordId - xoá 1 từ
exports.delete_a_word = async (req, res) => {
  try {
    const deleted = await Vocab.findByIdAndRemove(req.params.wordId).exec();
    if (!deleted) {
      return res.status(404).json({ message: 'Word not found' });
    }
    res.json({ message: 'Word successfully deleted', id: req.params.wordId });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting word', error: err });
  }
};

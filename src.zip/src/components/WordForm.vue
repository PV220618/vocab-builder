<template>
  <form class="ui form" @submit.prevent="onSubmit">
    <div class="field">
      <label>English</label>
      <input type="text" v-model="localWord.english" placeholder="English word" />
    </div>

    <div class="field">
      <label>German</label>
      <input type="text" v-model="localWord.german" placeholder="German translation" />
    </div>

    <div class="field">
      <label>Spanish</label>
      <input type="text" v-model="localWord.spanish" placeholder="Spanish translation" />
    </div>

    <div v-if="errorsPresent" class="ui red message">
      All fields are required.
    </div>

    <button class="ui primary button" type="submit">
      {{ submitLabel }}
    </button>
  </form>
</template>

<script>
export default {
  name: 'WordForm',
  props: {
    word: {
      type: Object,
      default: () => ({
        english: '',
        german: '',
        spanish: '',
      }),
    },
    submitLabel: {
      type: String,
      default: 'Save',
    },
  },
  data() {
    return {
      errorsPresent: false,
      localWord: {
        english: this.word.english || '',
        german: this.word.german || '',
        spanish: this.word.spanish || '',
      },
    };
  },
  watch: {
    word: {
      deep: true,
      handler(newVal) {
        this.localWord = {
          english: newVal.english || '',
          german: newVal.german || '',
          spanish: newVal.spanish || '',
        };
      },
    },
  },
  methods: {
    onSubmit() {
      if (
        !this.localWord.english.trim() ||
        !this.localWord.german.trim() ||
        !this.localWord.spanish.trim()
      ) {
        this.errorsPresent = true;
        return;
      }

      this.errorsPresent = false;

      // emit to parent component
      this.$emit('createOrUpdate', { ...this.localWord });
    },
  },
};
</script>

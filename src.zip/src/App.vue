<template>
  <div id="app" class="ui container">
    <div class="ui menu">
      <div class="header item">Vocab Builder</div>
      <router-link class="item" :to="{ name: 'words' }">All Words</router-link>
      <router-link class="item" :to="{ name: 'new' }">Add New</router-link>
      <router-link class="item" :to="{ name: 'test' }">Test Yourself</router-link>
    </div>

    <flash-message></flash-message>

    <div class="ui segment">
      <router-view />
    </div>
  </div>
</template>

<script>
export default { name: 'App' };
</script>

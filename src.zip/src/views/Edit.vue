<template>
  <div>
    <h2 class="ui header">Edit Word</h2>

    <word-form
      v-if="word"
      :word="word"
      submitLabel="Update"
      @createOrUpdate="onUpdate"
    />

    <div v-else class="ui active inline loader"></div>
  </div>
</template>

<script>
import { api } from "../helpers/helpers";
import WordForm from "../components/WordForm.vue";

export default {
  name: "Edit",
  components: { WordForm },

  data() {
    return { word: null };
  },

  async mounted() {
    this.word = await api.getWord(this.$route.params.id);
  },

  methods: {
    async onUpdate(updated) {
      const id = this.$route.params.id;
      await api.updateWord(id, updated);
      this.$router.push({ name: "show", params: { id } });
    },
  },
};
</script>

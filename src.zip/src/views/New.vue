<template>
  <div>
    <h2 class="ui header">Add New Word</h2>

    <word-form :word="word" submitLabel="Create" @createOrUpdate="onCreate" />
  </div>
</template>

<script>
import { api } from "../helpers/helpers";
import WordForm from "../components/WordForm.vue";

export default {
  name: "New",
  components: { WordForm },

  data() {
    return {
      word: {
        english: "",
        german: "",
        spanish: "",
      },
    };
  },

  methods: {
    async onCreate(newWord) {
      const created = await api.createWord(newWord);
      this.$router.push({ name: "show", params: { id: created._id } });
    },
  },
};
</script>

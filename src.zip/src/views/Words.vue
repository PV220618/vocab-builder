<template>
  <div>
    <h2 class="ui header">All Words</h2>

    <div class="ui form">
      <div class="fields">
        <div class="eight wide field">
          <label>Search</label>
          <input
            type="text"
            v-model="searchTerm"
            placeholder="Search English / German / Spanish"
          />
        </div>

        <div class="four wide field">
          <label>Filter</label>
          <select v-model="filterLang" class="ui dropdown">
            <option value="all">All</option>
            <option value="english">English Not Empty</option>
            <option value="german">German Not Empty</option>
            <option value="spanish">Spanish Not Empty</option>
          </select>
        </div>
      </div>
    </div>

    <table class="ui celled table">
      <thead>
        <tr>
          <th>English</th>
          <th>German</th>
          <th>Spanish</th>
          <th class="collapsing">Actions</th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="word in filteredWords" :key="word._id">
          <td>{{ word.english }}</td>
          <td>{{ word.german }}</td>
          <td>{{ word.spanish }}</td>

          <td>
            <router-link
              class="ui mini button"
              :to="{ name: 'show', params: { id: word._id }}"
              >View</router-link
            >

            <router-link
              class="ui mini button"
              :to="{ name: 'edit', params: { id: word._id }}"
              >Edit</router-link
            >

            <button
              class="ui red mini button"
              @click.prevent="onDelete(word._id)"
            >
              Delete
            </button>
          </td>
        </tr>

        <tr v-if="!filteredWords.length">
          <td colspan="4" class="center aligned">No results found.</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { api } from "../helpers/helpers";

export default {
  name: "Words",
  data() {
    return {
      words: [],
      searchTerm: "",
      filterLang: "all",
    };
  },

  computed: {
    filteredWords() {
      const term = this.searchTerm.toLowerCase();

      return this.words.filter((w) => {
        const match =
          w.english.toLowerCase().includes(term) ||
          w.german.toLowerCase().includes(term) ||
          w.spanish.toLowerCase().includes(term);

        if (!match) return false;

        if (this.filterLang === "english") return !!w.english;
        if (this.filterLang === "german") return !!w.german;
        if (this.filterLang === "spanish") return !!w.spanish;

        return true;
      });
    },
  },

  async mounted() {
    this.words = await api.getWords();
  },

  methods: {
    async onDelete(id) {
      const ok = window.confirm("Are you sure you want to delete?");
      if (!ok) return;

      await api.deleteWord(id);
      this.words = this.words.filter((w) => w._id !== id);
    },
  },
};
</script>

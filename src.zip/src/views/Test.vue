<template>
  <div>
    <h2 class="ui header">Test Yourself</h2>

    <div v-if="!words.length">
      <div class="ui active inline loader"></div>
    </div>

    <div v-else class="ui segment">
      <h3 class="ui header">Question {{ index + 1 }} / {{ words.length }}</h3>

      <p><strong>English:</strong> {{ current.english }}</p>

      <div class="ui form">
        <div class="field">
          <label>Your answer (German or Spanish)</label>
          <input
            type="text"
            v-model="userInput"
            placeholder="Enter translation"
            @keyup.enter="checkAnswer"
          />
        </div>
      </div>

      <button class="ui primary button" @click="checkAnswer">Check</button>
      <button class="ui button" @click="nextQuestion">Next</button>

      <div v-if="feedback" class="ui message" :class="messageClass">
        {{ feedback }}
      </div>

      <div class="ui divider"></div>

      <p><strong>Score:</strong> {{ score }} / {{ attempts }}</p>
    </div>
  </div>
</template>

<script>
import { api } from "../helpers/helpers";

export default {
  name: "Test",

  data() {
    return {
      words: [],
      index: 0,
      userInput: "",
      feedback: "",
      lastCorrect: null,
      score: 0,
      attempts: 0,
    };
  },

  computed: {
    current() {
      return this.words[this.index] || {};
    },

    messageClass() {
      if (this.lastCorrect === true) return "positive";
      if (this.lastCorrect === false) return "negative";
      return "";
    },
  },

  async mounted() {
    const all = await api.getWords();
    this.words = all.sort(() => Math.random() - 0.5);
  },

  methods: {
    checkAnswer() {
      if (!this.userInput.trim()) return;

      const ans = this.userInput.trim().toLowerCase();
      const { german, spanish } = this.current;

      const correct =
        german.toLowerCase() === ans || spanish.toLowerCase() === ans;

      this.lastCorrect = correct;
      this.attempts++;

      if (correct) {
        this.score++;
        this.feedback = `Correct! German: ${german}, Spanish: ${spanish}`;
      } else {
        this.feedback = `Wrong! Correct: German = ${german}, Spanish = ${spanish}`;
      }
    },

    nextQuestion() {
      this.userInput = "";
      this.feedback = "";
      this.lastCorrect = null;

      if (this.index < this.words.length - 1) {
        this.index++;
      } else {
        this.index = 0;
      }
    },
  },
};
</script>

<template>
  <div v-if="word">
    <h2 class="ui header">{{ word.english }}</h2>

    <div class="ui list">
      <div class="item"><strong>German:</strong> {{ word.german }}</div>
      <div class="item"><strong>Spanish:</strong> {{ word.spanish }}</div>
      <div class="item"><strong>Created:</strong> {{ formattedDate }}</div>
    </div>

    <router-link
      class="ui button primary"
      :to="{ name: 'edit', params: { id: word._id }}"
      >Edit</router-link
    >
    <router-link class="ui button" :to="{ name: 'words' }">Back</router-link>
  </div>

  <div v-else>
    <div class="ui active inline loader"></div>
  </div>
</template>

<script>
import { api } from "../helpers/helpers";

export default {
  name: "Show",
  data() {
    return {
      word: null,
    };
  },

  computed: {
    formattedDate() {
      if (!this.word) return "";
      return new Date(this.word.createdAt).toLocaleString();
    },
  },

  async mounted() {
    this.word = await api.getWord(this.$route.params.id);
  },
};
</script>

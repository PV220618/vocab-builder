// src/helpers/helpers.js
import Vue from 'vue';
import axios from 'axios';
import VueFlashMessage from 'vue-flash-message';

import 'vue-flash-message/dist/vue-flash-message.min.css';

Vue.use(VueFlashMessage, {
  messageOptions: {
    timeout: 3000,
    pauseOnInteract: true,
  },
});

// Vue instance để dùng flash ở ngoài component
const vm = new Vue();

// API base URL (front-end gọi back-end)
const baseURL = 'http://localhost:3000';

function handleError(error, message = 'Something went wrong') {
  console.error(error);
  vm.flash(message, 'error');
  throw error;
}

const api = {
  async getWords() {
    try {
      const res = await axios.get(`${baseURL}/words`);
      return res.data;
    } catch (err) {
      handleError(err, 'Failed to load words');
    }
  },

  async getWord(id) {
    try {
      const res = await axios.get(`${baseURL}/words/${id}`);
      return res.data;
    } catch (err) {
      handleError(err, 'Failed to load word');
    }
  },

  async createWord(word) {
    try {
      const res = await axios.post(`${baseURL}/words`, word);
      vm.flash('Word created successfully', 'success');
      return res.data;
    } catch (err) {
      handleError(err, 'Failed to create word');
    }
  },

  async updateWord(id, word) {
    try {
      const res = await axios.put(`${baseURL}/words/${id}`, word);
      vm.flash('Word updated successfully', 'success');
      return res.data;
    } catch (err) {
      handleError(err, 'Failed to update word');
    }
  },

  async deleteWord(id) {
    try {
      await axios.delete(`${baseURL}/words/${id}`);
      vm.flash('Word deleted successfully', 'success');
    } catch (err) {
      handleError(err, 'Failed to delete word');
    }
  },
};

export { api, vm };
